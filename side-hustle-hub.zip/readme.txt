========================================================================
             WELCOME TO SIDE HUSTLE HUB (TINA EDITION)
========================================================================

This portal is a custom-built, lightweight, light-themed web application
designed to help you build, grow, and monetize your side hustle community.

Inside, you will find:
- A Match Finder Quiz matching budget, skills, and goals.
- Profit Yield & Operating Margin Calculators (Airbnb, E-Commerce, Social).
- Launch Checklists for students.
- A Junior Side Hustles Corner for kids with a Piggy Bank calculator.
- A private Admin Studio with YouTube & Facebook content calendars,
  growth checklists, and monetization models.

------------------------------------------------------------------------
AUTHENTICATION CREDENTIALS (TINA'S ADMIN ACCESS)
------------------------------------------------------------------------
To log in as Admin and unlock your studio and calendars:
1. Click the "Login / Join Portal" tab in the sidebar.
2. Enter the following details:
   - Email: tina@hustle.com
   - Password: tina123
3. Click "Verify & Log In". You will be taken directly to the Admin Studio!

------------------------------------------------------------------------
OPTION 1: THE FASTEST WAY (DEPLOY ONLINE IN 60 SECONDS)
------------------------------------------------------------------------
You can publish this portal online for FREE so anyone can access it:
1. Locate the "dist" folder inside this unzipped directory.
2. Open your web browser and go to: https://app.netlify.com/drop
3. Drag the "dist" folder and drop it onto the Netlify upload box.
4. Netlify will instantly deploy it and give you a live website link
   (e.g., https://your-hustle-hub.netlify.app) to share with your audience!

------------------------------------------------------------------------
OPTION 2: RUN THE PORTAL LOCALLY ON YOUR COMPUTER
------------------------------------------------------------------------
To run and edit the code locally on your machine:
1. Install Node.js:
   Download and install Node.js from https://nodejs.org/ (use recommended version).
2. Open your terminal / command prompt and navigate to this folder:
   cd side-hustle-hub
3. Install dependencies:
   Run: npm install
4. Start the local server:
   Run: npm run dev
5. Open your web browser and navigate to the address shown in the terminal
   (usually http://localhost:5173 or http://localhost:8085).

========================================================================
Enjoy building your community!
========================================================================
