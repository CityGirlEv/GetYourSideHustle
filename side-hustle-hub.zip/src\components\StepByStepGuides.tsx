import React, { useState } from "react";
import { 
  Check, 
  AlertTriangle, 
  Award,
  ArrowRight,
  TrendingUp,
  Coins
} from "lucide-react";

interface GuideStep {
  title: string;
  desc: string;
}

interface GuideData {
  id: string;
  name: string;
  timeframe: string;
  estEarnings: string;
  bestFor: string;
  steps: GuideStep[];
  proTip: string;
  pitfall: string;
}

interface StepByStepGuidesProps {
  selectedHustleId?: string;
  onGoToCalculator: (hustleId: string) => void;
}

export const StepByStepGuides: React.FC<StepByStepGuidesProps> = ({ 
  selectedHustleId = "airbnb",
  onGoToCalculator
}) => {
  const [activeGuideId, setActiveGuideId] = useState<string>(selectedHustleId);
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({});

  const guides: GuideData[] = [
    {
      id: "airbnb",
      name: "Airbnb Hosting",
      timeframe: "2 - 4 weeks",
      estEarnings: "$1,500 - $8,000 / month",
      bestFor: "Property owners or sublease managers looking to monetize space.",
      proTip: "Invest in a high-quality smart lock (e.g., Yale or Schlage) that integrates with Airbnb to auto-generate keypad codes for guests upon check-in. It saves hours of manual work.",
      pitfall: "Not checking local regulations or HOA rules. Many cities require short-term rental (STR) permits, and violating HOAs can result in major fines.",
      steps: [
        { title: "Market & Feasibility Audit", desc: "Use tools like AirDNA to check average occupancy, nightly rates, and municipal regulations in your ZIP code." },
        { title: "Secure STR Permits & Insurance", desc: "Apply for local city licenses and purchase short-term rental-specific liability insurance." },
        { title: "Furnish & Style (Cozy Aesthetic)", desc: "Buy durable, photogenic furniture. Focus on comfortable mattresses, high-speed WiFi, and guest amenities (coffee, shampoo)." },
        { title: "Professional Photography & Copy", desc: "Hire a real estate photographer. Write an engaging title focusing on unique features (e.g., 'Cozy Oasis with Hot Tub')." },
        { title: "Build the Listing & Pricing Strategy", desc: "Create your Airbnb account, set clear house rules, and turn on dynamic pricing (PriceLabs or Wheelhouse) to maximize high-season occupancy." },
        { title: "Automate Cleaning & Communication", desc: "Partner with local cleaners via TurnoverBnB to auto-schedule cleaning sessions based on checkout times." }
      ]
    },
    {
      id: "pod",
      name: "Print-on-Demand (POD)",
      timeframe: "1 - 2 weeks",
      estEarnings: "$200 - $3,000 / month",
      bestFor: "Creatives and designers who want zero inventory risk.",
      proTip: "Don't design for everyone. Focus on hyperspecific niches (e.g., 'Retro Coffee-Loving Software Engineers'). People buy items that represent their specific identity.",
      pitfall: "Copying trademarked text or copyrighted art. Etsy and Amazon will permanently ban stores that violate IP laws.",
      steps: [
        { title: "Select Niches & Run Keyword Audits", desc: "Use Etsy Search or Google Trends to find low-competition, passionate niches (hobbies, professions, humor)." },
        { title: "Create Printify or Printful Accounts", desc: "Register with a POD supplier and link it to your sales channel (Etsy shop, Shopify, or eBay)." },
        { title: "Draft Eye-Catching Designs", desc: "Create transparent PNG designs (300 DPI) using Canva, Illustrator, or Figma. Focus on clean typography and aesthetic color palettes." },
        { title: "Publish Listings with SEO Tags", desc: "Optimize title keywords, description tags, and upload realistic mockups (Placeit) so customers see how the item looks in real life." },
        { title: "Promote on Pinterest & TikTok", desc: "Create aesthetic boards showing lifestyle mockups or record short-form video hooks of the products." },
        { title: "Iterate Based on Traffic Data", desc: "Check which listings get views/favorites, double down on what works, and phase out low-performing designs." }
      ]
    },
    {
      id: "dropshipping",
      name: "Dropshipping Business",
      timeframe: "2 - 3 weeks",
      estEarnings: "$500 - $10,000 / month",
      bestFor: "Digital marketers ready to run paid advertisements.",
      proTip: "Order a sample of the product to your house first. You must verify shipping times, product build quality, and record custom video ad creatives.",
      pitfall: "Relying on low-quality suppliers with 30-day shipping times. Modern consumers expect delivery in under 10 days; long waits lead to refunds and bank chargebacks.",
      steps: [
        { title: "Perform Competitor & TikTok Research", desc: "Find viral products with high problem-solving value or a strong wow-factor using TikTok's Ad Library." },
        { title: "Source Suppliers on Alibaba or Zendrop", desc: "Establish agreements with reliable suppliers offering fast-shipping lines (5-10 days to US/Europe)." },
        { title: "Construct Shopify Landing Pages", desc: "Set up a clean, single-product Shopify store. Use trust badges, customer reviews, and clear return policies." },
        { title: "Produce High-Clickrate Video Ads", desc: "Record or edit 3 unique hook variations (first 3 seconds) and a solid call-to-action for Facebook/TikTok Ads." },
        { title: "Launch Paid Marketing Tests", desc: "Run budget testing campaigns ($20-50/day) targeting broad interest matches. Analyze CTR (aim for >2%) and CPA." },
        { title: "Optimize Cart & Scale Budgets", desc: "Use upsells to increase Average Order Value (AOV) and gradually increase ad spend on profitable target assets." }
      ]
    },
    {
      id: "affiliate",
      name: "Affiliate Marketing",
      timeframe: "3 - 6 weeks",
      estEarnings: "$100 - $15,000 / month",
      bestFor: "Writers, bloggers, and review content creators.",
      proTip: "Focus on promoting high-ticket SaaS tools (software with monthly subscriptions). They offer recurring commissions, meaning you get paid every month the user stays.",
      pitfall: "Spamming links everywhere. Without providing genuine educational value or detailed tutorials, social platforms will block your posts and people won't buy.",
      steps: [
        { title: "Choose a Domain / Industry Vertical", desc: "Pick a niche you understand (e.g., marketing tools, fitness tech, personal finance) to build credibility." },
        { title: "Apply to Premium Networks", desc: "Join Amazon Associates, ClickBank, Impact.com, or individual SaaS partner programs directly." },
        { title: "Launch Content Hubs", desc: "Establish a blog, YouTube channel, or email list to host your guides, comparison sheets, and tutorials." },
        { title: "Create Comparison & Review Articles", desc: "Write exhaustive reviews (e.g., 'Tool A vs Tool B: The Honest Truth'). Focus on resolving user query search intent." },
        { title: "Set Up Lead Magnets & Email Funnels", desc: "Collect emails using a free PDF guide. Follow up with value-first automated newsletters containing affiliate solutions." },
        { title: "Monitor CTR & Conversion Analytics", desc: "Track which landing pages drive clicks. Optimize buttons and call-outs to increase affiliate link CTR." }
      ]
    },
    {
      id: "amazon",
      name: "Amazon FBA (Fulfillment by Amazon)",
      timeframe: "4 - 8 weeks",
      estEarnings: "$1,000 - $25,000 / month",
      bestFor: "Aspiring physical brand builders with capital ready to invest.",
      proTip: "Perform deep product differentiation. Don't sell the exact same item as 50 other listings. Bundle it, change the color, improve the packaging, or fix a common complaint found in negative competitor reviews.",
      pitfall: "Running out of stock during your launch phase. Amazon's organic ranking algorithm penalizes listings that go out of stock, destroying your PPC progress.",
      steps: [
        { title: "Perform Junglescout/Helium10 Audits", desc: "Find high-volume, low-review niches with steady year-round demand." },
        { title: "Source Suppliers & Request Samples", desc: "Contact gold-rated suppliers on Alibaba. Negotiate pricing, packaging customization, and order sample sets." },
        { title: "Register Amazon Seller Central", desc: "Establish your business entity (LLC), apply for an Amazon Seller account, and register your trademark for brand registry." },
        { title: "Arrange Freight Shipping (FOB/DDP)", desc: "Coordinate with a freight forwarder to ship goods from the manufacturer directly to Amazon fulfillment centers." },
        { title: "Build Optimized Product Detail Pages", desc: "Create high-converting infographics, write bullet points explaining benefits, and upload 3D render images." },
        { title: "Launch PPC & Review Campaigns", desc: "Run Sponsored Products ads targeting high-intent keywords. Use Amazon Vine to secure your first 5-10 trusted customer reviews." }
      ]
    },
    {
      id: "social",
      name: "Social Influencer & Creator",
      timeframe: "4 - 12 weeks",
      estEarnings: "$500 - $20,000 / month",
      bestFor: "Charismatic storytellers who enjoy editing and content creation.",
      proTip: "Post consistently at the same time every day. Algorithms favor accounts with predictable publishing cadences. Batch-create content on weekends to stay ahead.",
      pitfall: "Buying fake followers. Brands run analytics checks (like HypeAuditor) before sponsorships. Low engagement rates (under 1.5%) reveal fake metrics instantly.",
      steps: [
        { title: "Define Content Pillars & Target Viewer", desc: "Determine your theme (e.g., personal finance tips for Gen Z, coding tutorials, style makeovers)." },
        { title: "Create Channel Accounts & Bios", desc: "Optimize profiles across TikTok, IG, and YouTube Shorts. Use a high-quality headshot and clear, benefits-driven bio description." },
        { title: "Batch-Record Short-form Videos", desc: "Script and film 10-15 short-form clips. Start with strong hooks (first 2 seconds), add subtitles, and keep edits fast-paced." },
        { title: "Implement Daily Publishing Cadence", desc: "Post 1-2 videos daily. Use trending audio tracks, niche-relevant tags, and pinned comments to start discussion." },
        { title: "Assemble Sponsor Media Kits", desc: "Create a 1-page PDF showing audience demographics (age, location), engagement rate, and past video metrics." },
        { title: "Sign Brand Sponsor Contracts", desc: "Register on creator marketplaces (TikTok Creator Marketplace, Cohley) and pitch brands direct sponsorship deals." }
      ]
    }
  ];

  const activeGuide = guides.find(g => g.id === activeGuideId) || guides[0];

  // Calculate completion percentage for the active guide
  const activeStepsCount = activeGuide.steps.length;
  const activeCompletedSteps = activeGuide.steps.filter((_, idx) => 
    completedSteps[`${activeGuide.id}-${idx}`]
  ).length;
  const progressPercent = activeStepsCount > 0 ? (activeCompletedSteps / activeStepsCount) * 100 : 0;

  const toggleStep = (stepIdx: number) => {
    const key = `${activeGuide.id}-${stepIdx}`;
    setCompletedSteps(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "250px 1fr", gap: "32px" }}>
      
      {/* Sidebar Selector */}
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)", textTransform: "uppercase", fontWeight: 700, letterSpacing: "0.05em", paddingLeft: "8px" }}>
          Select Guide
        </span>
        {guides.map((g, idx) => (
          <button
            key={idx}
            onClick={() => setActiveGuideId(g.id)}
            className={`nav-link-btn ${activeGuideId === g.id ? "active" : ""}`}
            style={{ padding: "10px 14px", fontSize: "0.9rem" }}
          >
            {g.name}
          </button>
        ))}
      </div>

      {/* Main Guide Content */}
      <div className="glass" style={{ padding: "32px", borderRadius: "20px" }}>
        {/* Header summary */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "16px", marginBottom: "28px", borderBottom: "1px solid var(--border-color)", paddingBottom: "24px" }}>
          <div>
            <span className="glow-badge purple" style={{ marginBottom: "8px" }}>
              Launch Checklist
            </span>
            <h2 style={{ fontSize: "1.75rem", color: "white", marginBottom: "6px" }}>{activeGuide.name} Setup</h2>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", maxWidth: "600px" }}>{activeGuide.bestFor}</p>
          </div>

          <div style={{ 
            background: "rgba(255,255,255,0.01)", 
            padding: "16px", 
            borderRadius: "12px", 
            border: "1px solid var(--border-color)",
            fontSize: "0.85rem",
            minWidth: "220px"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
              <span style={{ color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "4px" }}><Coins size={14} /> Startup Time:</span>
              <strong style={{ color: "white" }}>{activeGuide.timeframe}</strong>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "4px" }}><TrendingUp size={14} /> Est. Return:</span>
              <strong style={{ color: "var(--accent-emerald)" }}>{activeGuide.estEarnings}</strong>
            </div>
          </div>
        </div>

        {/* Progress Tracker */}
        <div style={{ marginBottom: "32px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", color: "var(--text-secondary)", marginBottom: "8px" }}>
            <span>Launch Roadmap Progress</span>
            <span style={{ fontWeight: 700, color: progressPercent === 100 ? "var(--accent-emerald)" : "white" }}>
              {activeCompletedSteps} of {activeStepsCount} Completed ({Math.round(progressPercent)}%)
            </span>
          </div>
          <div style={{ width: "100%", height: "8px", background: "rgba(255,255,255,0.05)", borderRadius: "9999px", overflow: "hidden" }}>
            <div style={{ 
              width: `${progressPercent}%`, 
              height: "100%", 
              background: progressPercent === 100 ? "var(--grad-emerald)" : "var(--grad-primary)",
              borderRadius: "9999px",
              transition: "width var(--transition-normal)"
            }} />
          </div>
        </div>

        {/* Checklist Steps */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "32px" }}>
          {activeGuide.steps.map((step, idx) => {
            const isDone = !!completedSteps[`${activeGuide.id}-${idx}`];
            return (
              <div 
                key={idx} 
                onClick={() => toggleStep(idx)}
                className={`checklist-item ${isDone ? "completed" : ""}`}
              >
                <div className="checklist-checkbox">
                  {isDone && <Check size={12} />}
                </div>
                <div className="checklist-text">
                  <strong style={{ color: isDone ? "var(--text-muted)" : "white", fontSize: "0.95rem", display: "block", marginBottom: "4px" }}>
                    {idx + 1}. {step.title}
                  </strong>
                  <span style={{ color: isDone ? "var(--text-muted)" : "var(--text-secondary)", fontSize: "0.85rem" }}>
                    {step.desc}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pro Tip & Pitfall callouts */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px" }}>
          <div style={{ 
            padding: "20px", 
            borderRadius: "12px", 
            border: "1px solid rgba(16, 185, 129, 0.15)", 
            background: "rgba(16, 185, 129, 0.015)" 
          }}>
            <h4 style={{ color: "var(--accent-emerald)", fontSize: "0.95rem", fontWeight: 700, display: "flex", alignItems: "center", gap: "6px", marginBottom: "8px" }}>
              <Award size={16} /> Professional Secret
            </h4>
            <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>{activeGuide.proTip}</p>
          </div>

          <div style={{ 
            padding: "20px", 
            borderRadius: "12px", 
            border: "1px solid rgba(239, 68, 68, 0.15)", 
            background: "rgba(239, 68, 68, 0.015)" 
          }}>
            <h4 style={{ color: "#ef4444", fontSize: "0.95rem", fontWeight: 700, display: "flex", alignItems: "center", gap: "6px", marginBottom: "8px" }}>
              <AlertTriangle size={16} /> High-Risk Pitfall
            </h4>
            <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>{activeGuide.pitfall}</p>
          </div>
        </div>

        {/* Footer Actions */}
        <div style={{ marginTop: "32px", borderTop: "1px solid var(--border-color)", paddingTop: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}>
            Ready to calculate your customized returns?
          </span>
          <button 
            onClick={() => onGoToCalculator(activeGuide.id)}
            className="btn btn-outline"
            style={{ fontSize: "0.85rem", gap: "6px" }}
          >
            Launch Revenue Calculator <ArrowRight size={14} />
          </button>
        </div>

      </div>

    </div>
  );
};
