import { useState } from "react";
import { 
  Compass, 
  Calculator, 
  BookOpen, 
  MessageSquare, 
  Sparkles,
  Search,
  Flame,
  Smile,
  User,
  Shield,
  LogIn,
  LogOut
} from "lucide-react";
import { HustleCard } from "./components/HustleCard";
import type { Hustle } from "./components/HustleCard";
import { CalculatorSection } from "./components/CalculatorSection";
import { HustleQuiz } from "./components/HustleQuiz";
import { StepByStepGuides } from "./components/StepByStepGuides";
import { CommunityHub } from "./components/CommunityHub";
import { KidsCorner } from "./components/KidsCorner";
import { UserPortal } from "./components/UserPortal";
import { AdminPortal } from "./components/AdminPortal";
import "./App.css";

const HUSTLES_DATA: Hustle[] = [
  {
    id: "airbnb",
    name: "Airbnb Hosting",
    description: "Rent out spare rooms, guest houses, or entire properties on the world's largest homestay platform for short-term travellers.",
    startupCost: "Over $1,000",
    timeReq: "10 - 20 hrs/week",
    difficulty: "Medium",
    potentialIncome: "$1,500 - $8,000/mo",
    type: "Active / Passive",
    gradient: "pink",
    category: "Real Estate",
    iconName: "airbnb",
    details: [
      "No property ownership required if doing rental arbitrage",
      "Dynamic pricing maximizes earnings based on weekends/seasonality",
      "High startup costs (furniture, decor, locks)"
    ]
  },
  {
    id: "pod",
    name: "Print-on-Demand (POD)",
    description: "Design custom shirts, mugs, and merchandise, and sell them via Etsy or Shopify with zero warehousing or inventory costs.",
    startupCost: "Less than $100",
    timeReq: "5 - 10 hrs/week",
    difficulty: "Easy",
    potentialIncome: "$200 - $3,000/mo",
    type: "Passive",
    gradient: "purple",
    category: "E-Commerce",
    iconName: "pod",
    details: [
      "100% passive once designs are published",
      "Zero upfront product cost - items printed only when sold",
      "Competitive niche requiring good keyword SEO"
    ]
  },
  {
    id: "dropshipping",
    name: "Dropshipping",
    description: "Build an online storefront and source products directly from suppliers who package and ship orders straight to customers.",
    startupCost: "$100 - $1,000",
    timeReq: "15 - 25 hrs/week",
    difficulty: "Hard",
    potentialIncome: "$500 - $10,000/mo",
    type: "Active",
    gradient: "cyan",
    category: "E-Commerce",
    iconName: "dropshipping",
    details: [
      "High dependency on Facebook/TikTok advertising campaigns",
      "Customer service & supplier relations require active attention",
      "Enormous scaling capability"
    ]
  },
  {
    id: "affiliate",
    name: "Affiliate Marketing",
    description: "Earn passive referral commissions by creating helpful reviews and tutorials promoting other brands' products.",
    startupCost: "Less than $100",
    timeReq: "5 - 15 hrs/week",
    difficulty: "Medium",
    potentialIncome: "$100 - $15,000/mo",
    type: "Passive",
    gradient: "emerald",
    category: "Digital",
    iconName: "affiliate",
    details: [
      "Focuses heavily on search SEO and value-first content hubs",
      "Best with recurring software programs (SaaS affiliate fees)",
      "Slow launch but creates long-term recurring profit"
    ]
  },
  {
    id: "amazon",
    name: "Amazon FBA Seller",
    description: "Launch your own physical product brand on Amazon. Amazon stores, packages, ships, and handles returns on your behalf.",
    startupCost: "Over $1,000",
    timeReq: "20 - 30 hrs/week",
    difficulty: "Hard",
    potentialIncome: "$1,000 - $25,000/mo",
    type: "Active",
    gradient: "amber",
    category: "E-Commerce",
    iconName: "amazon",
    details: [
      "Requires manufacturing partnerships (typically via Alibaba)",
      "High earning potential in Amazon's massive organic buyer network",
      "Complex supply chain and Amazon catalog SEO rules"
    ]
  },
  {
    id: "social",
    name: "Social Influencer",
    description: "Build a highly engaged audience around your interests, and monetize with brand sponsors, affiliate links, and creator funds.",
    startupCost: "Less than $100",
    timeReq: "15 - 30 hrs/week",
    difficulty: "Medium",
    potentialIncome: "$500 - $20,000/mo",
    type: "Active",
    gradient: "pink",
    category: "Creative",
    iconName: "social",
    details: [
      "Builds a personal brand that can launch secondary businesses",
      "Requires consistent video publishing cadences to feed algorithm",
      "High rates for sponsorship integrations with engaged audiences"
    ]
  }
];

function App() {
  const [activeView, setActiveView] = useState<"dashboard" | "quiz" | "calculators" | "guides" | "community" | "kids" | "login" | "user_portal" | "admin">("dashboard");
  const [selectedHustleId, setSelectedHustleId] = useState<string>("airbnb");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");

  // Auth states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<"user" | "admin">("user");
  const [emailInput, setEmailInput] = useState("");
  const [passInput, setPassInput] = useState("");
  const [loginError, setLoginError] = useState("");

  const handleSelectHustleAction = (hustleId: string, actionType: "calculator" | "guide") => {
    setSelectedHustleId(hustleId);
    if (actionType === "calculator") {
      setActiveView("calculators");
    } else {
      setActiveView("guides");
    }
  };

  const handleGoToCalculatorFromGuide = (hustleId: string) => {
    setSelectedHustleId(hustleId);
    setActiveView("calculators");
  };

  const handleGoToGuideFromCalculator = (hustleId: string) => {
    setSelectedHustleId(hustleId);
    setActiveView("guides");
  };

  // Login handler
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    
    const email = emailInput.trim().toLowerCase();
    const pass = passInput;

    if (email === "tina@hustle.com" && pass === "tina123") {
      setIsLoggedIn(true);
      setUserRole("admin");
      setActiveView("admin");
      setEmailInput("");
      setPassInput("");
    } else if (email && pass) {
      // Normal guest login
      setIsLoggedIn(true);
      setUserRole("user");
      setActiveView("user_portal");
      setEmailInput("");
      setPassInput("");
    } else {
      setLoginError("Please enter a valid email and password.");
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserRole("user");
    setActiveView("dashboard");
  };

  // Filter Categories
  const categories = ["all", "E-Commerce", "Real Estate", "Digital", "Creative"];

  // Filter & Search Hustles
  const filteredHustles = HUSTLES_DATA.filter(h => {
    const matchesSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          h.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === "all" || h.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const getHeaderTitle = () => {
    switch (activeView) {
      case "dashboard": return "Discover Side Hustles";
      case "quiz": return "Match Finder Wizard";
      case "calculators": return "Profit Estimator Pro";
      case "guides": return "Launch Checklists";
      case "community": return "Creator Community";
      case "kids": return "Kids Side Hustle Corner";
      case "login": return "Hustle Portal Access";
      case "user_portal": return "My Member Dashboard";
      case "admin": return "Tina's Admin Studio";
      default: return "Side Hustle Hub";
    }
  };

  const getHeaderDesc = () => {
    switch (activeView) {
      case "dashboard": return "Explore verified side hustles. Learn step-by-step guides to scale your earnings.";
      case "quiz": return "Find which side hustle matches your starting capital, schedule, and interests.";
      case "calculators": return "Estimate dynamic net cash flows, product margins, and affiliate returns.";
      case "guides": return "Follow our comprehensive roadmaps to build, launch, and monetize your pilot.";
      case "community": return "Ask questions, share updates, and exchange tips with active creators.";
      case "kids": return "Fun, safe, parent-approved projects for children and teens to earn pocket money.";
      case "login": return "Log in to save checklist bookmarks, unlock badges, and track launch milestones.";
      case "user_portal": return "Check your checklist marks, view unlocked achievement badges, and track milestones.";
      case "admin": return "Manage your social content calendars, explore growth checklists, and check monetization models.";
      default: return "";
    }
  };

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div className="brand-section">
          <div className="brand-logo">
            <Flame size={20} style={{ fill: "white" }} />
          </div>
          <span className="brand-name">Hustle Hub</span>
        </div>

        <nav>
          <ul className="nav-links">
            <li>
              <button 
                onClick={() => setActiveView("dashboard")}
                className={`nav-link-btn ${activeView === "dashboard" ? "active" : ""}`}
              >
                <Compass size={18} />
                Dashboard
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveView("quiz")}
                className={`nav-link-btn ${activeView === "quiz" ? "active" : ""}`}
              >
                <Sparkles size={18} />
                Match Finder
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveView("calculators")}
                className={`nav-link-btn ${activeView === "calculators" ? "active" : ""}`}
              >
                <Calculator size={18} />
                Calculators
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveView("guides")}
                className={`nav-link-btn ${activeView === "guides" ? "active" : ""}`}
              >
                <BookOpen size={18} />
                Launch Guides
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveView("kids")}
                className={`nav-link-btn ${activeView === "kids" ? "active" : ""}`}
              >
                <Smile size={18} />
                Kids Corner
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveView("community")}
                className={`nav-link-btn ${activeView === "community" ? "active" : ""}`}
              >
                <MessageSquare size={18} />
                Community Space
              </button>
            </li>
            
            <li style={{ marginTop: "16px", borderTop: "1px solid var(--border-color)", paddingTop: "16px" }}>
              {isLoggedIn ? (
                <button 
                  onClick={() => setActiveView(userRole === "admin" ? "admin" : "user_portal")}
                  className={`nav-link-btn ${(activeView === "user_portal" || activeView === "admin") ? "active" : ""}`}
                >
                  {userRole === "admin" ? <Shield size={18} /> : <User size={18} />}
                  {userRole === "admin" ? "Admin Studio 👑" : "My Member Portal"}
                </button>
              ) : (
                <button 
                  onClick={() => setActiveView("login")}
                  className={`nav-link-btn ${activeView === "login" ? "active" : ""}`}
                >
                  <LogIn size={18} />
                  Login / Join Portal
                </button>
              )}
            </li>
          </ul>
        </nav>

        {/* User Card */}
        <div className="sidebar-footer">
          {isLoggedIn ? (
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              <div className="user-profile">
                <div className="avatar" style={{ background: userRole === "admin" ? "var(--grad-primary)" : "var(--grad-pink)" }}></div>
                <div className="user-info">
                  <span className="user-name">{userRole === "admin" ? "Tina (Admin)" : "Guest Pilot"}</span>
                  <span className="user-role">{userRole === "admin" ? "Studio Owner" : "Premium Member"}</span>
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="btn btn-outline" 
                style={{ width: "100%", padding: "6px 12px", fontSize: "0.8rem", gap: "6px" }}
              >
                <LogOut size={12} /> Log Out
              </button>
            </div>
          ) : (
            <div className="user-profile">
              <div className="avatar" style={{ background: "rgba(0,0,0,0.05)" }}></div>
              <div className="user-info">
                <span className="user-name">Guest Pilot</span>
                <span className="user-role">Anonymous Reader</span>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Main Panel */}
      <main className="main-content">
        {/* Header */}
        <header className="header-row">
          <div className="header-title-section">
            <h1 style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              {getHeaderTitle()}
            </h1>
            <p>{getHeaderDesc()}</p>
          </div>

          <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
            <span className="glow-badge pink">
              Tina Approved ✨
            </span>
          </div>
        </header>

        {/* View Switcher */}
        {activeView === "dashboard" && (
          <div>
            {/* Onboarding START HERE card (Highly prominent, yellow/purple gradient) */}
            <div 
              className="glass" 
              style={{ 
                padding: "28px", 
                borderRadius: "20px", 
                background: "linear-gradient(135deg, rgba(253, 224, 71, 0.2), rgba(124, 58, 237, 0.05))",
                border: "2px solid #facc15",
                marginBottom: "32px",
                boxShadow: "0 10px 30px -5px rgba(250, 204, 21, 0.15)"
              }}
            >
              <span className="glow-badge amber" style={{ border: "1px solid #eab308", background: "#fef08a", color: "#a16207", marginBottom: "12px", fontWeight: 800 }}>
                👉 START HERE: Quick Onboarding Guide
              </span>
              <h2 style={{ fontSize: "1.5rem", color: "#1e293b", marginBottom: "12px" }}>
                Welcome to your Side Hustle Pilot Portal!
              </h2>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.925rem", lineHeight: "1.6", marginBottom: "20px" }}>
                We have built this platform to take the guesswork out of launch mechanics. Get started in three easy steps:
              </p>

              <div style={{ 
                display: "grid", 
                gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", 
                gap: "16px",
                fontSize: "0.85rem",
                color: "var(--text-primary)"
              }}>
                <div style={{ padding: "16px", borderRadius: "12px", background: "#ffffff", border: "1px solid rgba(124, 58, 237, 0.08)" }}>
                  <strong style={{ color: "var(--accent-purple)", display: "block", marginBottom: "4px" }}>Step 1: Match Finder Quiz</strong>
                  Answer budget and schedule questions to automatically find your custom side hustle recommendation.
                </div>
                <div style={{ padding: "16px", borderRadius: "12px", background: "#ffffff", border: "1px solid rgba(124, 58, 237, 0.08)" }}>
                  <strong style={{ color: "var(--accent-cyan)", display: "block", marginBottom: "4px" }}>Step 2: Profit Sliders</strong>
                  Adjust nightly booking rates, unit sales volumes, and marketing costs to estimate operating profits.
                </div>
                <div style={{ padding: "16px", borderRadius: "12px", background: "#ffffff", border: "1px solid rgba(124, 58, 237, 0.08)" }}>
                  <strong style={{ color: "var(--accent-emerald)", display: "block", marginBottom: "4px" }}>Step 3: Step-by-Step Checklists</strong>
                  Follow detailed launch checklists covering permits, sourcing, dynamic tools, and supplier setups.
                </div>
              </div>

              <div style={{ marginTop: "24px", display: "flex", gap: "12px" }}>
                <button onClick={() => setActiveView("quiz")} className="btn btn-primary">
                  Launch Match Quiz <Sparkles size={16} />
                </button>
                <button onClick={() => setActiveView("kids")} className="btn btn-outline">
                  Visit Kids Side Hustle Corner
                </button>
              </div>
            </div>

            {/* Main Hero Summary Card */}
            <div className="glass hero-card" style={{ borderRadius: "20px" }}>
              <div style={{ maxWidth: "700px" }}>
                <h2 style={{ fontSize: "1.85rem", color: "var(--text-primary)", marginBottom: "12px", lineHeight: "1.2" }}>
                  Discover Modern Income Streams
                </h2>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem", marginBottom: "24px", lineHeight: "1.6" }}>
                  Whether you want to set up an Airbnb listing, launch Print-on-Demand designs, open a Dropshipping storefront, or build a personal creator brand on social media, find the exact blueprints here.
                </p>

                <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
                  <button 
                    onClick={() => setActiveView("quiz")}
                    className="btn btn-primary"
                  >
                    Find Your Match
                  </button>
                  <button 
                    onClick={() => setActiveView("community")}
                    className="btn btn-outline"
                  >
                    Browse Community Threads
                  </button>
                </div>
              </div>
            </div>

            {/* Filter & Search Section */}
            <div style={{ 
              display: "flex", 
              justifyContent: "space-between", 
              alignItems: "center", 
              flexWrap: "wrap", 
              gap: "16px",
              marginTop: "40px",
              marginBottom: "24px"
            }}>
              {/* Category Filter list */}
              <div style={{ display: "flex", gap: "8px", overflowX: "auto", paddingBottom: "4px" }}>
                {categories.map((c, idx) => (
                  <button
                    key={idx}
                    onClick={() => setFilterCategory(c)}
                    className={`glow-badge ${filterCategory === c ? "purple" : ""}`}
                    style={{ 
                      cursor: "pointer", 
                      border: filterCategory === c ? "1px solid var(--accent-purple)" : "1px solid var(--border-color)",
                      background: filterCategory === c ? "rgba(124, 58, 237, 0.08)" : "rgba(255,255,255,0.8)",
                      color: filterCategory === c ? "var(--accent-purple)" : "var(--text-secondary)",
                      padding: "6px 14px",
                      textTransform: "capitalize",
                      whiteSpace: "nowrap"
                    }}
                  >
                    {c === "all" ? "All Hustles" : c}
                  </button>
                ))}
              </div>

              {/* Search Bar */}
              <div style={{ position: "relative", minWidth: "260px" }}>
                <Search 
                  size={16} 
                  style={{ 
                    position: "absolute", 
                    left: "14px", 
                    top: "50%", 
                    transform: "translateY(-50%)", 
                    color: "var(--text-muted)" 
                  }} 
                />
                <input 
                  type="text" 
                  placeholder="Search opportunities..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="text-input"
                  style={{ paddingLeft: "42px", height: "42px" }}
                />
              </div>
            </div>

            {/* Grid List */}
            {filteredHustles.length > 0 ? (
              <div className="hustle-grid">
                {filteredHustles.map((hustle) => (
                  <HustleCard 
                    key={hustle.id} 
                    hustle={hustle} 
                    onSelectAction={handleSelectHustleAction}
                  />
                ))}
              </div>
            ) : (
              <div className="glass" style={{ padding: "48px", textAlign: "center", borderRadius: "16px" }}>
                <p style={{ color: "var(--text-secondary)", marginBottom: "16px" }}>No side hustles match your search criteria.</p>
                <button onClick={() => { setSearchQuery(""); setFilterCategory("all"); }} className="btn btn-outline">
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        )}

        {activeView === "quiz" && (
          <HustleQuiz 
            hustles={HUSTLES_DATA} 
            onSelectAction={handleSelectHustleAction}
          />
        )}

        {activeView === "calculators" && (
          <CalculatorSection 
            initialActiveTab={
              selectedHustleId === "pod" || selectedHustleId === "dropshipping" || selectedHustleId === "amazon" 
                ? "ecom" 
                : selectedHustleId === "social" || selectedHustleId === "affiliate"
                ? "social"
                : "airbnb"
            }
            onGoToGuide={handleGoToGuideFromCalculator}
          />
        )}

        {activeView === "guides" && (
          <StepByStepGuides 
            selectedHustleId={selectedHustleId}
            onGoToCalculator={handleGoToCalculatorFromGuide}
          />
        )}

        {activeView === "community" && (
          <CommunityHub />
        )}

        {activeView === "kids" && (
          <KidsCorner />
        )}

        {/* View: User / Admin Login form */}
        {activeView === "login" && (
          <div style={{ maxWidth: "420px", margin: "40px auto" }} className="glass">
            <div style={{ padding: "32px", borderRadius: "16px" }}>
              <div style={{ textAlign: "center", marginBottom: "28px" }}>
                <div className="brand-logo" style={{ margin: "0 auto 16px auto", width: "48px", height: "48px" }}>
                  <LogIn size={20} />
                </div>
                <h2 style={{ fontSize: "1.4rem", color: "var(--text-primary)", marginBottom: "6px" }}>Sign In to Member Portal</h2>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>
                  Unlock customized bookmark trackers, weekly content calendars, and success badges.
                </p>
              </div>

              <form onSubmit={handleLoginSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                {loginError && (
                  <div style={{ padding: "10px", background: "rgba(239, 68, 68, 0.05)", border: "1px solid rgba(239, 68, 68, 0.2)", borderRadius: "8px", color: "#ef4444", fontSize: "0.8rem", textAlign: "center" }}>
                    {loginError}
                  </div>
                )}
                
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label" style={{ fontSize: "0.8rem" }}>Email Address</label>
                  <input 
                    type="email" 
                    placeholder="e.g. tina@hustle.com" 
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    className="text-input"
                    required
                  />
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label" style={{ fontSize: "0.8rem" }}>Password</label>
                  <input 
                    type="password" 
                    placeholder="Enter password" 
                    value={passInput}
                    onChange={(e) => setPassInput(e.target.value)}
                    className="text-input"
                    required
                  />
                </div>

                <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: "10px" }}>
                  Verify & Log In
                </button>
              </form>

              <div style={{ marginTop: "24px", paddingTop: "20px", borderTop: "1px solid var(--border-color)", fontSize: "0.8rem", color: "var(--text-muted)", textAlign: "center" }}>
                <p style={{ marginBottom: "6px" }}><strong>Testing Credentials:</strong></p>
                <p>Tina (Admin): <code>tina@hustle.com</code> / <code>tina123</code></p>
                <p style={{ marginTop: "4px" }}>Guest (User): Enter any email & password</p>
              </div>
            </div>
          </div>
        )}

        {activeView === "user_portal" && (
          <UserPortal />
        )}

        {activeView === "admin" && (
          <AdminPortal />
        )}
      </main>
    </div>
  );
}

export default App;
