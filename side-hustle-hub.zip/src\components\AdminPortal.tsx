import React, { useState } from "react";
import { 
  Calendar, 
  TrendingUp, 
  DollarSign, 
  Sparkles, 
  Check, 
  Clock 
} from "lucide-react";

interface ScheduleItem {
  id: string;
  day: string;
  platform: "youtube" | "facebook";
  topic: string;
  hook: string;
  keywords: string;
  scheduledTime: string;
  status: "Draft" | "Scheduled" | "Published";
}

export const AdminPortal: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<"calendar" | "monetize" | "growth">("calendar");
  const [schedule, setSchedule] = useState<ScheduleItem[]>([
    {
      id: "1",
      day: "Monday",
      platform: "youtube",
      topic: "I Tested 5 Side Hustles Under $100 (Honest 30-Day Results)",
      hook: "Most side hustles are complete scams. That's why I spent my own money and 30 days testing 5 of the most popular ones to show you what actually works.",
      keywords: "side hustles for beginners, make money online, work from home jobs",
      scheduledTime: "10:00 AM EST",
      status: "Published"
    },
    {
      id: "2",
      day: "Monday",
      platform: "facebook",
      topic: "Discussion Poll: What is your primary obstacle keeping you from launching a side hustle?",
      hook: "Hey Hustlers! Let's talk about what's holding you back. Vote below and let's troubleshoot it in the comments!",
      keywords: "Engagement booster / community interaction",
      scheduledTime: "12:00 PM EST",
      status: "Published"
    },
    {
      id: "3",
      day: "Wednesday",
      platform: "youtube",
      topic: "How to Start Airbnb Arbitrage Without Buying Property (Legal Step-by-Step)",
      hook: "You do not need a million dollars in real estate to make $5,000 a month on Airbnb. Here is the legal lease contract blueprint to rent properties and list them.",
      keywords: "airbnb rental arbitrage, real estate side hustles, passive income airbnb",
      scheduledTime: "10:00 AM EST",
      status: "Scheduled"
    },
    {
      id: "4",
      day: "Wednesday",
      platform: "facebook",
      topic: "Case Study Summary: How Brian Miller broke $10k/mo with Amazon FBA",
      hook: "Brian started 6 months ago with a simple wholesale product. Today, Amazon handles all his packing and shipping while he travels. Read his AliBaba sourcing tips in this short post!",
      keywords: "Value-first post / drives traffic to website",
      scheduledTime: "1:00 PM EST",
      status: "Scheduled"
    },
    {
      id: "5",
      day: "Friday",
      platform: "youtube",
      topic: "The Lazy Way to Sell Shirts: Etsy Print-on-Demand Tutorial",
      hook: "I made my first sale on Etsy in less than 24 hours without printing or shipping a single shirt myself. Let me show you how to link Printify in under 10 minutes.",
      keywords: "print on demand tutorial, etsy printify guide, print on demand for beginners",
      scheduledTime: "10:00 AM EST",
      status: "Draft"
    },
    {
      id: "6",
      day: "Friday",
      platform: "facebook",
      topic: "Free Resource Friday: Launch Guide Link Roundup",
      hook: "Happy Friday! We just uploaded 6 complete launch checklists on our portal (Airbnb, FBA, Dropshipping, POD). Click below to find your match and get started!",
      keywords: "Drives traffic to side-hustle-hub checklist portal",
      scheduledTime: "9:00 AM EST",
      status: "Draft"
    }
  ]);

  const toggleStatus = (id: string) => {
    setSchedule(prev => prev.map(item => {
      if (item.id === id) {
        const nextStatus: Record<string, "Draft" | "Scheduled" | "Published"> = {
          "Draft": "Scheduled",
          "Scheduled": "Published",
          "Published": "Draft"
        };
        return { ...item, status: nextStatus[item.status] };
      }
      return item;
    }));
  };

  return (
    <div>
      {/* Intro Panel */}
      <div className="glass" style={{ padding: "28px", borderRadius: "16px", marginBottom: "28px", background: "linear-gradient(135deg, #ffffff, rgba(124, 58, 237, 0.02))" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "16px" }}>
          <div>
            <span className="glow-badge purple" style={{ marginBottom: "8px" }}>Admin Panel</span>
            <h2 style={{ fontSize: "1.6rem", color: "var(--accent-purple)", marginBottom: "6px" }}>Tina&apos;s Strategy Dashboard</h2>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem" }}>
              Plan content for your YouTube & Facebook pages, track monetization setup, and check growth workflows.
            </p>
          </div>
          <span className="glow-badge emerald">Logged In: Admin Tina</span>
        </div>
      </div>

      {/* Sub Tabs */}
      <div style={{ 
        display: "flex", 
        gap: "12px", 
        borderBottom: "1px solid var(--border-color)", 
        paddingBottom: "12px",
        marginBottom: "24px"
      }}>
        <button 
          onClick={() => setActiveSubTab("calendar")}
          className={`nav-link-btn ${activeSubTab === "calendar" ? "active" : ""}`}
          style={{ width: "auto", display: "inline-flex", padding: "8px 16px" }}
        >
          <Calendar size={16} /> Content Calendar
        </button>
        <button 
          onClick={() => setActiveSubTab("monetize")}
          className={`nav-link-btn ${activeSubTab === "monetize" ? "active" : ""}`}
          style={{ width: "auto", display: "inline-flex", padding: "8px 16px" }}
        >
          <DollarSign size={16} /> Monetization Blueprint
        </button>
        <button 
          onClick={() => setActiveSubTab("growth")}
          className={`nav-link-btn ${activeSubTab === "growth" ? "active" : ""}`}
          style={{ width: "auto", display: "inline-flex", padding: "8px 16px" }}
        >
          <TrendingUp size={16} /> Growth & Traffic Exploder
        </button>
      </div>

      {/* Sub Tab: Content Calendar */}
      {activeSubTab === "calendar" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h3 style={{ fontSize: "1.2rem", color: "var(--text-primary)" }}>YouTube & Facebook Publishing Schedule</h3>
            <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>Click status badge to toggle state (Draft → Scheduled → Published)</span>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {schedule.map(item => (
              <div 
                key={item.id} 
                className="glass" 
                style={{ 
                  padding: "20px", 
                  borderRadius: "12px",
                  borderLeft: `4px solid ${item.platform === "youtube" ? "#ef4444" : "#1877f2"}`,
                  background: "#ffffff"
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "12px", flexWrap: "wrap", gap: "10px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {item.platform === "youtube" ? (
                      <svg viewBox="0 0 24 24" width={18} height={18} fill="currentColor" style={{ color: "#ef4444" }}>
                        <path d="M23.498 6.163a3.003 3.003 0 0 0-2.11-2.11C19.518 3.545 12 3.545 12 3.545s-7.518 0-9.388.508a3.003 3.003 0 0 0-2.11 2.11C0 8.033 0 12 0 12s0 3.967.502 5.837a3.003 3.003 0 0 0 2.11 2.11c1.87.508 9.388.508 9.388.508s7.518 0 9.388-.508a3.003 3.003 0 0 0 2.11-2.11C24 15.967 24 12 24 12s0-3.967-.502-5.837zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" width={18} height={18} fill="currentColor" style={{ color: "#1877f2" }}>
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                      </svg>
                    )}
                    <strong style={{ fontSize: "0.95rem", color: "var(--text-primary)", textTransform: "capitalize" }}>
                      {item.platform} Post — {item.day} ({item.scheduledTime})
                    </strong>
                  </div>

                  <button 
                    onClick={() => toggleStatus(item.id)}
                    className={`glow-badge ${
                      item.status === "Published" ? "emerald" : 
                      item.status === "Scheduled" ? "cyan" : "amber"
                    }`}
                    style={{ cursor: "pointer", border: "1px solid currentColor" }}
                  >
                    {item.status === "Published" && <Check size={12} />}
                    {item.status === "Scheduled" && <Clock size={12} />}
                    {item.status}
                  </button>
                </div>

                <div style={{ marginBottom: "12px" }}>
                  <span style={{ fontSize: "0.8rem", color: "var(--text-muted)", display: "block" }}>Topic / Content Title:</span>
                  <span style={{ fontSize: "0.925rem", color: "var(--text-primary)", fontWeight: 600 }}>{item.topic}</span>
                </div>

                <div style={{ padding: "12px", background: "rgba(0,0,0,0.01)", borderRadius: "8px", border: "1px solid var(--border-color)", marginBottom: "12px" }}>
                  <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", display: "block", marginBottom: "4px" }}>Video Script Hook / Text Copy:</span>
                  <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", fontStyle: "italic", lineHeight: "1.5" }}>&ldquo;{item.hook}&rdquo;</p>
                </div>

                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                  <span><strong>SEO Keywords / Tags:</strong> {item.keywords}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub Tab: Monetization Blueprint */}
      {activeSubTab === "monetize" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          
          <div className="glass" style={{ padding: "24px", borderRadius: "14px" }}>
            <h3 style={{ fontSize: "1.2rem", color: "var(--text-primary)", marginBottom: "16px", display: "flex", alignItems: "center", gap: "8px" }}>
              <DollarSign size={20} style={{ color: "var(--accent-purple)" }} /> High-yield Monetization Streams for Tina
            </h3>

            <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <div style={{ display: "flex", gap: "16px", alignItems: "flex-start" }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "rgba(124, 58, 237, 0.08)", display: "flex", alignItems: "center", flexShrink: 0, marginTop: "2px", color: "var(--accent-purple)", justifyContent: "center" }}><strong>1</strong></div>
                <div>
                  <h4 style={{ fontSize: "1rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "4px" }}>E-Commerce Affiliate Integrations</h4>
                  <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                    Insert your custom affiliate links inside the step-by-step launch checklists. For example, recommend **Printify** in the POD checklist, **Shopify & Zendrop** in the Dropshipping checklist, and **Bluehost/Hostinger** in the Affiliate Marketing checklist. When users read your tutorials and build businesses, you earn commissions.
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", gap: "16px", alignItems: "flex-start" }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "rgba(124, 58, 237, 0.08)", display: "flex", alignItems: "center", flexShrink: 0, marginTop: "2px", color: "var(--accent-purple)", justifyContent: "center" }}><strong>2</strong></div>
                <div>
                  <h4 style={{ fontSize: "1rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "4px" }}>Premium Community Circles ($19 - $49 / month)</h4>
                  <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                    Create a private, members-only mastermind group. Monetize by providing members with live monthly Q&A group coaching calls with you, a database of vetted wholesale suppliers, and templates (like lease contracts for Airbnb rental arbitrage).
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", gap: "16px", alignItems: "flex-start" }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "rgba(124, 58, 237, 0.08)", display: "flex", alignItems: "center", flexShrink: 0, marginTop: "2px", color: "var(--accent-purple)", justifyContent: "center" }}><strong>3</strong></div>
                <div>
                  <h4 style={{ fontSize: "1rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "4px" }}>Digital Launch Kit Bundles</h4>
                  <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                    Sell digital download packs directly from the dashboard. Build an Airbnb Arbitrage Landlord Pitch Deck, ready-made dropshipping video scripts templates, or social media content calendars. Price them at $27 - $47 for immediate, high-margin revenue.
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", gap: "16px", alignItems: "flex-start" }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "rgba(124, 58, 237, 0.08)", display: "flex", alignItems: "center", flexShrink: 0, marginTop: "2px", color: "var(--accent-purple)", justifyContent: "center" }}><strong>4</strong></div>
                <div>
                  <h4 style={{ fontSize: "1rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "4px" }}>Paid Mentor Listings ($99 / month)</h4>
                  <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                    Charge successful side hustlers a monthly directory fee to list themselves as featured mentors. Beginners buy coaching calls from these mentors, and you charge the mentors a listing fee.
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", gap: "16px", alignItems: "flex-start" }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "rgba(124, 58, 237, 0.08)", display: "flex", alignItems: "center", flexShrink: 0, marginTop: "2px", color: "var(--accent-purple)", justifyContent: "center" }}><strong>5</strong></div>
                <div>
                  <h4 style={{ fontSize: "1rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "4px" }}>Calculators Software Sponsorships</h4>
                  <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                    Sell ad space directly on your interactive calculators page to tools that align with calculations (e.g. dynamic pricing software on the Airbnb calculator, or ad analytics tool on the Dropshipping calculator).
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub Tab: Growth exploder */}
      {activeSubTab === "growth" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          
          <div className="glass" style={{ padding: "24px", borderRadius: "14px" }}>
            <h3 style={{ fontSize: "1.2rem", color: "var(--text-primary)", marginBottom: "16px", display: "flex", alignItems: "center", gap: "8px" }}>
              <Sparkles size={20} style={{ color: "var(--accent-cyan)" }} /> How to Explode Tina&apos;s Social Engagement
            </h3>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
              <div style={{ padding: "16px", borderRadius: "10px", border: "1px solid var(--border-color)" }}>
                <h4 style={{ fontSize: "0.95rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "8px" }}>
                  Short-form Video Multiplying
                </h4>
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                  Take 30-second clips of your YouTube videos (like highlighting the Airbnb smart lock tip or printing keychains), add colorful subtitles, and repost them daily as **YouTube Shorts, TikToks, and Facebook Reels**. Reel traffic is organic and explodes quickly.
                </p>
              </div>

              <div style={{ padding: "16px", borderRadius: "10px", border: "1px solid var(--border-color)" }}>
                <h4 style={{ fontSize: "0.95rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "8px" }}>
                  Value-First Lead Magnet
                </h4>
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                  Include a pin-comment on YouTube: &ldquo;Compare your potential side hustle profits using our free interactive calculators at side-hustle-hub.&rdquo; Gathering traffic onto the portal lets you build an email list of subscribers you can sell premium classes to.
                </p>
              </div>

              <div style={{ padding: "16px", borderRadius: "10px", border: "1px solid var(--border-color)" }}>
                <h4 style={{ fontSize: "0.95rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "8px" }}>
                  Simultaneous Live Streaming
                </h4>
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                  Go Live on YouTube and Facebook at the same time once a week. Do an audit: &ldquo;Rating My Subscribers&apos; Side Hustle Ideas Live.&rdquo; Live streams get pushed to new viewers by algorithms, boosting page likes.
                </p>
              </div>

              <div style={{ padding: "16px", borderRadius: "10px", border: "1px solid var(--border-color)" }}>
                <h4 style={{ fontSize: "0.95rem", color: "var(--text-primary)", fontWeight: 600, marginBottom: "8px" }}>
                  Etsy/POD Design SEO Exploits
                </h4>
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: "1.5" }}>
                  Show the real-time design creations live. Showing screen layouts and showing actual Etsy shop sales graphs inside Facebook posts creates massive social proof, making your brand highly trusted.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
