import React, { useState } from "react";
import { 
  Smile, 
  ShieldAlert, 
  Coins, 
  Dog, 
  BookOpen, 
  Palette, 
  Laptop, 
  Gift 
} from "lucide-react";

interface JrHustle {
  name: string;
  desc: string;
  pay: string;
  difficulty: string;
  icon: React.ReactNode;
  safety: string;
}

export const KidsCorner: React.FC = () => {
  const [goalName, setGoalName] = useState("Cool Bicycle");
  const [goalCost, setGoalCost] = useState(150);
  const [customGoalTitle, setCustomGoalTitle] = useState("");
  const [customGoalPrice, setCustomGoalPrice] = useState(50);
  const [isCustomGoal, setIsCustomGoal] = useState(false);
  const [hustleRate, setHustleRate] = useState(15); // e.g. $15 per task

  const jrHustles: JrHustle[] = [
    {
      name: "Neighborhood Dog Walker 🐾",
      desc: "Help out busy neighbors by taking their friendly dogs for fun outdoor walks around the neighborhood.",
      pay: "$10 - $20 / walk",
      difficulty: "Very Easy 🌟",
      icon: <Dog size={24} style={{ color: "var(--accent-pink)" }} />,
      safety: "Always walk dogs with an adult nearby. Keep them on a short leash and stick to familiar sidewalks."
    },
    {
      name: "Yard & Garden Helper 🏡",
      desc: "Help rake colorful leaves, water pretty flowers, pull weeds, or shovel snow during winter time.",
      pay: "$15 - $30 / yard",
      difficulty: "Easy 🌟",
      icon: <Gift size={24} style={{ color: "var(--accent-emerald)" }} />,
      safety: "Never use heavy power tools like lawnmowers alone. Ask an adult to show you how to use hand tools safely."
    },
    {
      name: "Creative Sticker & Keychain Crafting 🎨",
      desc: "Draw cool pictures, write fun quotes, or bake clay charms to sell to friends, families, or school fairs.",
      pay: "$1 - $5 / item",
      difficulty: "Medium 🌟",
      icon: <Palette size={24} style={{ color: "var(--accent-purple)" }} />,
      safety: "Ask a parent for help when baking clay in the oven or shipping sticker envelopes to customers."
    },
    {
      name: "Senior Tech Helper 📱",
      desc: "Help grandparents or neighbors learn to send pictures, make video calls, or play online puzzle games.",
      pay: "$10 - $20 / hour",
      difficulty: "Easy 🌟",
      icon: <Laptop size={24} style={{ color: "var(--accent-cyan)" }} />,
      safety: "Never share your own private codes or passwords, and only help neighbors that your parents know well."
    },
    {
      name: "Homework Helper & Reader 📚",
      desc: "Help younger kids practice reading their books, practice spelling, or solve easy math flashcards.",
      pay: "$10 - $15 / hour",
      difficulty: "Medium 🌟",
      icon: <BookOpen size={24} style={{ color: "var(--accent-amber)" }} />,
      safety: "Host all study helper sessions in public spaces like the school library or with parents present."
    }
  ];

  // Calculators
  const finalGoalTitle = isCustomGoal ? (customGoalTitle || "My Goal") : goalName;
  const finalGoalCost = isCustomGoal ? customGoalPrice : goalCost;
  
  // Tasks needed = goal cost / rate
  const tasksNeeded = Math.ceil(finalGoalCost / hustleRate);

  const selectPredefinedGoal = (name: string, price: number) => {
    setIsCustomGoal(false);
    setGoalName(name);
    setGoalCost(price);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.1fr 0.9fr", gap: "32px" }}>
      
      {/* List of Kids Hustles */}
      <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
        
        {/* Intro */}
        <div className="glass" style={{ padding: "28px", borderRadius: "16px", background: "linear-gradient(135deg, #ffffff, rgba(219, 39, 119, 0.02))" }}>
          <h2 style={{ fontSize: "1.6rem", color: "var(--accent-pink)", marginBottom: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Smile size={24} /> Junior Side Hustle Corner!
          </h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem", lineHeight: "1.6" }}>
            Earning your own pocket money is a great way to learn responsibility and save up for cool toys, games, or bikes! Here are five safe, parent-approved side projects you can start today.
          </p>

          <div style={{ 
            marginTop: "16px", 
            background: "rgba(219, 39, 119, 0.04)", 
            border: "1px solid rgba(219, 39, 119, 0.15)", 
            padding: "16px", 
            borderRadius: "12px", 
            fontSize: "0.85rem",
            color: "var(--text-primary)",
            display: "flex",
            alignItems: "flex-start",
            gap: "10px"
          }}>
            <ShieldAlert size={20} style={{ color: "var(--accent-pink)", flexShrink: 0, marginTop: "2px" }} />
            <div>
              <strong>PARENTS & SAFETY FIRST:</strong> Before starting any hustle, discuss it with your parents. Never go into anyone's house alone, never share private details, and prioritize schoolwork!
            </div>
          </div>
        </div>

        {/* Hustle Items */}
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          {jrHustles.map((jh, idx) => (
            <div key={idx} className="glass" style={{ padding: "20px", borderRadius: "14px", border: "1px solid var(--border-color)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <div style={{ 
                    width: "40px", 
                    height: "40px", 
                    borderRadius: "8px", 
                    background: "rgba(124, 58, 237, 0.04)", 
                    display: "flex", 
                    alignItems: "center", 
                    justifyContent: "center" 
                  }}>
                    {jh.icon}
                  </div>
                  <h3 style={{ fontSize: "1.1rem", color: "var(--text-primary)" }}>{jh.name}</h3>
                </div>
                <span className="glow-badge emerald" style={{ fontSize: "0.7rem" }}>
                  {jh.difficulty}
                </span>
              </div>

              <p style={{ fontSize: "0.875rem", color: "var(--text-secondary)", marginBottom: "12px" }}>{jh.desc}</p>
              
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", background: "rgba(0,0,0,0.01)", padding: "10px", borderRadius: "8px", border: "1px solid var(--border-color)" }}>
                <div>
                  <span style={{ color: "var(--text-muted)", display: "block", fontSize: "0.75rem" }}>Est. Pay Rate</span>
                  <strong style={{ color: "var(--text-primary)" }}>{jh.pay}</strong>
                </div>
                <div style={{ maxWidth: "70%" }}>
                  <span style={{ color: "var(--text-muted)", display: "block", fontSize: "0.75rem" }}>Safety Tip</span>
                  <span style={{ color: "var(--accent-amber)", fontWeight: 500, fontSize: "0.8rem" }}>{jh.safety}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Piggy Bank Goal Calculator */}
      <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
        
        <div className="glass" style={{ padding: "28px", borderRadius: "16px" }}>
          <h3 style={{ fontSize: "1.25rem", color: "var(--text-primary)", marginBottom: "16px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Coins size={20} style={{ color: "var(--accent-amber)" }} /> Piggy Bank Savings Calculator
          </h3>

          <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginBottom: "20px" }}>
            Pick a goal or write in a custom one. Set your hustle earnings rate to see exactly how many walks or lawns are needed!
          </p>

          {/* Goal presets list */}
          <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "24px" }}>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", fontWeight: 700, textTransform: "uppercase" }}>Select Goal:</span>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
              <button 
                onClick={() => selectPredefinedGoal("New Video Game", 60)}
                className={`btn btn-outline ${goalName === "New Video Game" && !isCustomGoal ? "active" : ""}`}
                style={{ padding: "8px 12px", fontSize: "0.8rem" }}
              >
                🎮 Video Game ($60)
              </button>
              <button 
                onClick={() => selectPredefinedGoal("Cool Bicycle", 150)}
                className={`btn btn-outline ${goalName === "Cool Bicycle" && !isCustomGoal ? "active" : ""}`}
                style={{ padding: "8px 12px", fontSize: "0.8rem" }}
              >
                🚲 Bicycle ($150)
              </button>
              <button 
                onClick={() => selectPredefinedGoal("Tablet / iPad", 250)}
                className={`btn btn-outline ${goalName === "Tablet / iPad" && !isCustomGoal ? "active" : ""}`}
                style={{ padding: "8px 12px", fontSize: "0.8rem" }}
              >
                📱 Tablet ($250)
              </button>
              <button 
                onClick={() => setIsCustomGoal(true)}
                className={`btn btn-outline ${isCustomGoal ? "active" : ""}`}
                style={{ padding: "8px 12px", fontSize: "0.8rem" }}
              >
                ✏️ Custom Goal
              </button>
            </div>
          </div>

          {/* Custom goal form */}
          {isCustomGoal && (
            <div style={{ display: "flex", gap: "10px", marginBottom: "24px", flexDirection: "column" }}>
              <input
                type="text"
                placeholder="What is your goal? (e.g. Lego Set)"
                value={customGoalTitle}
                onChange={(e) => setCustomGoalTitle(e.target.value)}
                className="text-input"
                style={{ height: "38px", fontSize: "0.85rem" }}
              />
              <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
                <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)", whiteSpace: "nowrap" }}>Goal Price ($):</span>
                <input
                  type="number"
                  value={customGoalPrice}
                  onChange={(e) => setCustomGoalPrice(Math.max(1, Number(e.target.value)))}
                  className="text-input"
                  style={{ height: "38px", fontSize: "0.85rem", width: "100px" }}
                />
              </div>
            </div>
          )}

          {/* Hustle earnings rate slider */}
          <div className="form-group" style={{ marginBottom: "28px" }}>
            <label className="form-label">
              <span>My Pay Rate Per Task ($)</span>
              <span className="form-label-value" style={{ color: "var(--accent-amber)" }}>${hustleRate}</span>
            </label>
            <input 
              type="range" 
              min="2" 
              max="50" 
              step="1"
              value={hustleRate}
              onChange={(e) => setHustleRate(Number(e.target.value))}
              className="range-slider"
            />
          </div>

          {/* Calculator Output */}
          <div style={{ 
            background: "rgba(217, 119, 6, 0.03)", 
            border: "1px solid rgba(217, 119, 6, 0.12)", 
            padding: "24px", 
            borderRadius: "14px",
            textAlign: "center",
            boxShadow: "var(--shadow-sm)"
          }}>
            <span style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>To buy your target:</span>
            <h4 style={{ fontSize: "1.25rem", color: "var(--text-primary)", margin: "8px 0" }}>{finalGoalTitle} (${finalGoalCost})</h4>
            
            <div style={{ margin: "16px 0" }}>
              <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", display: "block" }}>You need to complete:</span>
              <h1 style={{ 
                fontSize: "3.5rem", 
                fontWeight: 800, 
                color: "var(--accent-amber)", 
                lineHeight: "1",
                filter: "drop-shadow(0 2px 8px var(--accent-amber-glow))"
              }}>
                {tasksNeeded}
              </h1>
              <span style={{ fontSize: "0.85rem", fontWeight: 600, color: "var(--text-secondary)" }}>
                {tasksNeeded === 1 ? "Job / Task" : "Jobs / Tasks"}
              </span>
            </div>

            {/* Visual Piggy Bank Fill */}
            <div style={{ marginTop: "24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "4px" }}>
                <span>Piggy Bank Status</span>
                <span>{hustleRate >= finalGoalCost ? "100%" : `${Math.round((hustleRate/finalGoalCost)*100)}% filled per job`}</span>
              </div>
              <div style={{ width: "100%", height: "8px", background: "rgba(0,0,0,0.03)", borderRadius: "9999px", overflow: "hidden" }}>
                <div style={{ 
                  width: `${Math.min(100, Math.round((hustleRate/finalGoalCost)*100))}%`, 
                  height: "100%", 
                  background: "var(--grad-amber)",
                  borderRadius: "9999px"
                }} />
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
