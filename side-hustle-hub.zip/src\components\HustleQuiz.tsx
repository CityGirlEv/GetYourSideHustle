import React, { useState } from "react";
import { 
  PiggyBank, 
  Clock, 
  BrainCircuit, 
  Target, 
  ArrowLeft, 
  ArrowRight, 
  RotateCcw,
  Sparkles,
  Calculator,
  BookOpen
} from "lucide-react";

interface HustleQuizProps {
  hustles: any[];
  onSelectAction: (hustleId: string, actionType: "calculator" | "guide") => void;
}

export const HustleQuiz: React.FC<HustleQuizProps> = ({ hustles, onSelectAction }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({
    budget: "",
    time: "",
    skill: "",
    goal: ""
  });
  const [resultHustleId, setResultHustleId] = useState<string | null>(null);

  const steps = [
    {
      key: "budget",
      title: "What is your startup budget?",
      subtitle: "How much capital are you comfortable investing to get started?",
      icon: <PiggyBank size={24} style={{ color: "var(--accent-cyan)" }} />,
      options: [
        { label: "Less than $100 (Shoestring)", value: "low" },
        { label: "$100 - $1,000 (Moderate)", value: "medium" },
        { label: "Over $1,000 (Capital-ready)", value: "high" }
      ]
    },
    {
      key: "time",
      title: "How many hours can you commit?",
      subtitle: "Be realistic about the weekly time you can dedicate.",
      icon: <Clock size={24} style={{ color: "var(--accent-purple)" }} />,
      options: [
        { label: "2 - 5 hours per week", value: "very_low" },
        { label: "5 - 15 hours per week", value: "medium" },
        { label: "15+ hours per week", value: "high" }
      ]
    },
    {
      key: "skill",
      title: "Where do your strengths lie?",
      subtitle: "Choose the skill area you're most interested in leveraging.",
      icon: <BrainCircuit size={24} style={{ color: "var(--accent-emerald)" }} />,
      options: [
        { label: "Creative, Design & Media", value: "creative" },
        { label: "Marketing, Sales & Writing", value: "marketing" },
        { label: "Operations, Management & Hosting", value: "operations" }
      ]
    },
    {
      key: "goal",
      title: "What is your primary goal?",
      subtitle: "What kind of business structure are you hoping to build?",
      icon: <Target size={24} style={{ color: "var(--accent-amber)" }} />,
      options: [
        { label: "Build automated, passive income streams", value: "passive" },
        { label: "Launch a scalable e-commerce brand", value: "scale" },
        { label: "Monetize property, spaces, or physical assets", value: "physical" },
        { label: "Build influence, content & personal brand", value: "brand" }
      ]
    }
  ];

  const handleSelectOption = (value: string) => {
    const key = steps[currentStep].key;
    setAnswers(prev => ({ ...prev, [key]: value }));
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      calculateResult();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const resetQuiz = () => {
    setCurrentStep(0);
    setAnswers({ budget: "", time: "", skill: "", goal: "" });
    setResultHustleId(null);
  };

  const calculateResult = () => {
    const { budget, skill, goal } = answers;
    
    // Recommendation rules
    if (goal === "physical" || skill === "operations") {
      setResultHustleId("airbnb");
    } else if (budget === "high" && goal === "scale") {
      setResultHustleId("amazon");
    } else if (skill === "creative" && goal === "brand") {
      setResultHustleId("social");
    } else if (budget === "low" && skill === "creative") {
      setResultHustleId("pod");
    } else if (budget === "medium" && goal === "scale") {
      setResultHustleId("dropshipping");
    } else if (budget === "low" && skill === "marketing") {
      setResultHustleId("affiliate");
    } else {
      // Default fallback based on budget
      if (budget === "low") {
        setResultHustleId("pod");
      } else if (budget === "medium") {
        setResultHustleId("dropshipping");
      } else {
        setResultHustleId("amazon");
      }
    }
  };

  const currentStepData = steps[currentStep];
  const progressPercent = ((currentStep) / steps.length) * 100;
  const selectedOptionValue = answers[currentStepData?.key];
  const matchedHustle = hustles.find(h => h.id === resultHustleId);

  return (
    <div className="glass" style={{ padding: "32px", maxWidth: "720px", margin: "0 auto", borderRadius: "20px" }}>
      {resultHustleId === null ? (
        // Quiz Questions view
        <div>
          {/* Progress fill */}
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "var(--text-secondary)", marginBottom: "8px" }}>
            <span>Match Finder Wizard</span>
            <span>Question {currentStep + 1} of {steps.length}</span>
          </div>
          <div className="quiz-progress-bar">
            <div className="quiz-progress-fill" style={{ width: `${progressPercent}%` }} />
          </div>

          {/* Header */}
          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
            <div style={{ 
              width: "48px", 
              height: "48px", 
              borderRadius: "12px", 
              background: "rgba(124, 58, 237, 0.03)", 
              border: "1px solid var(--border-color)", 
              display: "flex", 
              alignItems: "center", 
              justifyContent: "center" 
            }}>
              {currentStepData.icon}
            </div>
            <div>
              <h2 style={{ fontSize: "1.35rem", color: "var(--text-primary)" }}>{currentStepData.title}</h2>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem" }}>{currentStepData.subtitle}</p>
            </div>
          </div>

          {/* Options Grid */}
          <div className="quiz-options">
            {currentStepData.options.map((option, idx) => (
              <div
                key={idx}
                className={`quiz-option ${selectedOptionValue === option.value ? "selected" : ""}`}
                onClick={() => handleSelectOption(option.value)}
              >
                <div style={{ fontSize: "0.95rem", fontWeight: 600, color: "var(--text-primary)" }}>
                  {option.label}
                </div>
              </div>
            ))}
          </div>

          {/* Navigation buttons */}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "32px", borderTop: "1px solid var(--border-color)", paddingTop: "24px" }}>
            <button
              onClick={handleBack}
              disabled={currentStep === 0}
              className="btn btn-outline"
              style={{ padding: "10px 20px", visibility: currentStep === 0 ? "hidden" : "visible", gap: "6px" }}
            >
              <ArrowLeft size={16} /> Back
            </button>

            <button
              onClick={handleNext}
              disabled={!selectedOptionValue}
              className="btn btn-primary"
              style={{ padding: "10px 20px", gap: "6px" }}
            >
              {currentStep === steps.length - 1 ? (
                <>Find Matches <Sparkles size={16} /></>
              ) : (
                <>Next <ArrowRight size={16} /></>
              )}
            </button>
          </div>
        </div>
      ) : (
        // Results View
        <div style={{ textAlign: "center" }}>
          <div 
            className="brand-logo" 
            style={{ 
              width: "60px", 
              height: "60px", 
              background: "var(--grad-primary)",
              boxShadow: "0 4px 12px var(--accent-purple-glow)",
              borderRadius: "16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 20px auto"
            }}
          >
            <Sparkles size={28} />
          </div>

          <h2 style={{ fontSize: "1.75rem", color: "var(--text-primary)", marginBottom: "8px" }}>
            Your Top Side Hustle Match!
          </h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem", marginBottom: "28px" }}>
            Based on your budget, time, skills, and goals, we recommend starting with:
          </p>

          {/* Matched Card Preview */}
          {matchedHustle && (
            <div style={{ maxWidth: "420px", margin: "0 auto 24px auto", textAlign: "left" }}>
              <div className="glass-card" style={{ padding: "28px", border: "1px solid var(--accent-cyan)", background: "#ffffff" }}>
                <span className={`glow-badge ${matchedHustle.gradient}`} style={{ marginBottom: "12px" }}>
                  {matchedHustle.category}
                </span>
                <h3 style={{ fontSize: "1.35rem", color: "var(--text-primary)", marginBottom: "8px" }}>
                  {matchedHustle.name}
                </h3>
                <p style={{ fontSize: "0.875rem", color: "var(--text-secondary)", marginBottom: "20px" }}>
                  {matchedHustle.description}
                </p>

                <div style={{ display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.85rem", borderTop: "1px solid var(--border-color)", paddingTop: "16px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: "var(--text-muted)" }}>Difficulty:</span>
                    <strong style={{ color: "var(--text-primary)" }}>{matchedHustle.difficulty}</strong>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: "var(--text-muted)" }}>Income Potential:</span>
                    <strong style={{ color: "var(--accent-cyan)" }}>{matchedHustle.potentialIncome}</strong>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: "var(--text-muted)" }}>Startup Cost:</span>
                    <strong style={{ color: "var(--text-primary)" }}>{matchedHustle.startupCost}</strong>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Dynamic Criteria Explanation Panel */}
          <div style={{ 
            marginTop: "24px", 
            padding: "20px", 
            background: "rgba(124, 58, 237, 0.03)", 
            border: "1px solid rgba(124, 58, 237, 0.12)", 
            borderRadius: "12px", 
            textAlign: "left",
            fontSize: "0.85rem",
            maxWidth: "520px",
            margin: "0 auto 32px auto"
          }}>
            <strong style={{ color: "var(--accent-purple)", display: "block", marginBottom: "8px", fontSize: "0.9rem" }}>
              🔍 Wizard Recommendation Logic:
            </strong>
            <ul style={{ paddingLeft: "16px", color: "var(--text-secondary)", display: "flex", flexDirection: "column", gap: "6px" }}>
              <li>
                <strong>Capital Matching ({answers.budget === "low" ? "Under $100" : answers.budget === "medium" ? "$100-$1000" : "Over $1,000"}):</strong> Recommends hustles that fit within your budget bracket.
              </li>
              <li>
                <strong>Strength Target:</strong> Matches your core strength (<strong>{answers.skill === "creative" ? "Creative/Design" : answers.skill === "marketing" ? "Marketing/Sales" : "Operations/Hosting"}</strong>).
              </li>
              <li>
                <strong>Business Goal:</strong> Aligns with your aim to <strong>{answers.goal === "passive" ? "Automate passive flows" : answers.goal === "scale" ? "Scale an ecom brand" : answers.goal === "physical" ? "Monetize properties" : "Build an influencer brand"}</strong>.
              </li>
            </ul>
          </div>

          {/* Action buttons */}
          <div style={{ display: "flex", gap: "16px", justifyContent: "center", flexWrap: "wrap" }}>
            <button
              onClick={resetQuiz}
              className="btn btn-outline"
              style={{ gap: "6px" }}
            >
              <RotateCcw size={16} /> Retake Quiz
            </button>

            {matchedHustle && (
              <>
                <button
                  onClick={() => onSelectAction(matchedHustle.id, "calculator")}
                  className="btn btn-outline"
                  style={{ gap: "6px" }}
                >
                  <Calculator size={16} /> Calculator
                </button>
                <button
                  onClick={() => onSelectAction(matchedHustle.id, "guide")}
                  className="btn btn-primary"
                  style={{ 
                    gap: "6px",
                    background: `var(--grad-${matchedHustle.gradient})`,
                    boxShadow: `0 4px 15px var(--accent-${matchedHustle.gradient}-glow)`
                  }}
                >
                  <BookOpen size={16} /> Launch Guide
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
